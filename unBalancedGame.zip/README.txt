Hi! Welcome to A GAME, ABOUT THINGS.  

To start playing the game, run the main.py file on your computer. Make sure that your computer has python installed. Python 3.9 is recommended.

While in battle, you can follow the prompts to fight. Input a number to do the action that it corresponds to. You can also use !stats to view the stats of either you or your opponent.  

Have fun! 
