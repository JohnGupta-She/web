import random as r 

statfile = open('RPGelements.csv').read() 
death_messages = open('death_messages.txt').read().split('\n')

intro = {"Infernal Drake": "The air is getting warmer around you...Your lungs feel like they’re burning...", "Ocean Drake" : "Puddles seem to form around you...Your shoes become wet...", "Cloud Drake" : "A strong gust blows against you...You start to feel lightheaded...",  "Mountain Drake": "Dust kicks up around you...It’s getting hard to breathe...", "Elder Dragon" : "Impending doom approaches..."} 

debuffs = {"Infernal Drake": "Burn", "Ocean Drake" : "Anti-Heal", "Cloud Drake" : "Shred", "Mountain Drake": "Slow","Elder Dragon" : "Curse"} 

player_killed = {"Infernal Drake": "<Player name> was consumed by the flames, nothing but ashes remain.", "Ocean Drake" : "Oxygen failed to reach <Player name> from the depths of the ocean.", "Cloud Drake" : "<Player name>'s lungs turned into a perfect vacuum.", "Mountain Drake": "<Player name> was crushed under the weight of mountains.","Elder Dragon" : "<Player name> fell prey to their sins."} 

beat = {"Infernal Drake": "You feel the power of fire surge through you...Your attacks now have the chance of burning your target.", "Mountain Drake": "The power of earth hardens your skin...Your blocks now slightly damage your attacker.","Ocean Drake": "The healing powers of water flow through your veins...You heal a little every turn.","Cloud Drake": "Your strikes are blessed with the power of air...You now have a chance to hit twice in one turn.","Elder Dragon": "The ancient spirits of light and dark are finally put to rest." } 

def sumStats(di): 
    newli = []
    for x in di: 
        if x != "Name": 
            newli.append(di[x])  
    return sum(newli) 

def makeStats(file = statfile, list = [0,0,0,0,0,0]):  #Creates a dictionary of stats, list is a base case that sets everything to 0 if no arguements are given
        f = file[:file.find('\n')]  #Grabs the first line with the names of the stats
        newdi = {}  
        count = 0 
        for x in f.split(','):   
            x = x.strip() #Corrects any errors we make in the csv if we have any extra spaces
            if x == 'Name':  #The Name would be a str while the rest of the values are going to be int
                newdi[x] = list[count]
                count += 1 
            else: 
                newdi[x] = int(list[count])
                count += 1 
        return newdi   

def selectEnemy(file = statfile, phase = 1): #Selects an enemy from the csv and returns their stats
        possible_e = (file.split('\n,,,,,\n')[phase]).split('\n') #A line of ,,,,, represents a different phase of the game and the possible enemies for that phase
        chosen_e = r.choice(possible_e) #Chooses a random enemy 
        return chosen_e.split(',') #Returns the list of stats for the chosen enemy   

class entity:  
    def __init__(self, phase):
        self.stats = makeStats()
        self.phase = phase 
        self.state = ""
    
    def statCorrection(self, stats): #Applies some stat correction for each point put into a stat 
        stats["Health"] *= 5 
        stats["Attack"] *= 3 
        stats["Defense"] = round(stats["Defense"] / 20 + stats["Defense"] * .01 , 2) 
        stats["Crit"] = round(stats["Crit"] / 15 + stats["Crit"] * .01, 2)

    def printStats(self): 
        print(self.stats) 
        print("State:", self.state)
        
    def attack(self, obj, block = False):  
        damage = self.stats["Attack"] * (1  - obj.stats["Defense"]) #base damage of the attack
        if r.randint(0, 100) <= self.stats["Crit"] * 100: #Will the Attack crit?
            damage *= 2 
            print("A critical hit!")
        damage = round(damage) 

        if block: 
            damage *= 0.5
            damage = round(damage) 

        if obj.state == "Shred": 
            damage *= 1.2 
            print("The winds have penetrated", obj.stats["Name"] + '\'s' "vitals.")
            obj.state == "" 

        if isinstance(self, player): 
            if "Infernal" in self.buffs: 
                if r.randint(1,5) == 5: 
                    obj.state == "Burn" 
                    print("Your attack is blessed by the spirits of fire.")
                    print(obj.stats["Name"], "is set alight.") 

            if "Cloud" in self.buffs: 
                if r.randint(1,5) == 5: 
                    damage *= 2 
                    print("The spirits of wind has blessed your strikes. Your strike will hit twice.") 

        if isinstance(obj, player): 
            if "Mountain" in obj.buffs:
                if block: 
                    print("The spirits of earth retaliate against your assailant.")
                    self.stats["Health"] -= round(damage * .5)

        obj.stats["Health"] -= damage       
        print(self.stats["Name"], "hit", obj.stats["Name"], "for", damage, "damage.") 

        if self.state == "Curse": 
            if r.randint(1,5) == 5: 
                damge = round(damage * 0.1)
                self.stats["Health"] -= damage 
                print(self.stats["Name"], "has taken", damage, "damage because of the curse.")

        if self.state == "Burn": 
            self.stats["Health"] -= round(self.stats["Health"] * 0.125)
            print(self.stats["Name"], "has taken some burn damage.")

class enemy(entity):  
    def __init__(self, phase): 
        entity.__init__(self, phase)
        self.stats = makeStats(list=selectEnemy(phase=phase))  
        self.exp = sumStats(self.stats)
        self.exp *= 3 * phase
        self.statCorrection(self.stats)  
        print("A", r.choice(["feral", "savage", "wild", "ferocious", "foul"]), self.stats["Name"], "has", r.choice(["appeared", "attacked"]) + '.')

    def exp_drop(self):  #Determines how much exp the enemy would drop upon death.
        print(self.stats["Name"], "has dropped", self.exp, "exp.") 
        return self.exp

def type_select():
        type = input("What class do you want to be? \n 1. Rogue \n 2. Knight \n 3. Tank \n").strip()
        if type == '1':
            return "Rogue"
        elif type == '2':
            return "Knight"
        elif type == '3':
            return "Tank"
        else:
            print('That is not a valid input.')
            type_select() 

class player(entity): 
    def __init__(self):
        entity.__init__(self, 1)
        self.stats["Name"] = input("What is your name? \n").strip() 
        self.type = type_select() 
        name = self.stats["Name"]
        if self.type == "Rogue": 
            self.stats = {"Name": name, "Max Health": 0, "Health": 3, "Defense": 2, "Attack": 3, "Speed": 4, "Crit": 3} 
        if self.type == "Knight":
            self.stats = {"Name": name, "Max Health": 0, "Health": 5, "Defense": 3, "Attack": 3, "Speed": 2, "Crit": 2} 
        if self.type == "Tank":
            self.stats = {"Name": name, "Max Health": 0, "Health": 5, "Defense": 5, "Attack": 2, "Speed": 2, "Crit": 1} 
        self.statCorrection(self.stats)
        self.stats["Max Health"] = self.stats["Health"]
        self.items = [] 
        self.stats["Exp"] = 0  
        self.stats["Level"] = 0 
        self.buffs = []

    def death(self, killer): 
        if isinstance(killer, dragon): 
            message = player_killed[killer.stats["Name"]]
            message = message.replace("<Player name>", self.stats["Name"])
            print(message) 
        else: 
            message = r.choice(death_messages) 
            message = message.replace("<Player name>", self.stats["Name"])
            print(message) 
            print("Game Over")
        return True    
    
    def level_up(self): 
        requirement = 100 * (1.5 ** self.stats["Level"])
        if (self.stats["Exp"] >= requirement): 
            self.stats["Exp"] -= requirement
            self.stats["Level"] += 1   
            print("You have leveled up!")

            if self.type == "Rogue":
                self.stats["Max Health"] += round(0.08 * self.stats["Max Health"]) + 1
                self.stats["Health"] += round(0.08 * self.stats["Max Health"]) + 1
                self.stats["Defense"] +=  round(0.05 * self.stats["Defense"], 2)
                self.stats["Attack"] += round(0.25 * self.stats["Attack"]) + 1
                self.stats["Speed"] += 2
                self.stats["Crit"] += 0.05

            if self.type == "Knight": 
                self.stats["Max Health"] += round(0.2 * self.stats["Max Health"]) + 1
                self.stats["Health"] += round(0.2 * self.stats["Max Health"]) + 1
                self.stats["Defense"] +=  round(0.1 * self.stats["Defense"], 2)
                self.stats["Attack"] += round(0.2 * self.stats["Attack"]) + 1
                self.stats["Speed"] += 1
                self.stats["Crit"]  += 0.01

            if self.type == "Tank": 
                self.stats["Max Health"] += round(0.25 * self.stats["Max Health"]) + 1
                self.stats["Health"] += round(0.25 * self.stats["Max Health"]) + 1
                self.stats["Defense"] += round(0.25 * self.stats["Defense"], 2)
                self.stats["Attack"] += round(0.075 * self.stats["Attack"]) + 1
                self.stats["Speed"] += 1
                self.stats["Crit"] += 0.01 

            print(self.stats) 

    def use(self, index): 
        chosen = self.items[index]
        print("You have used a", chosen, '.')
        if "Health Potion" in chosen: 
            if self.state == "Anti-Heal":
                anti = 0.5 
            else: 
                anti = 1
            if "Lesser" in chosen: 
                if self.stats["Max Health"] < self.stats["Health"] + 10 * anti: 
                    self.stats["Health"] = self.stats["Max Health"]
                else:
                    self.stats["Health"] += round(10 * anti)
            elif "Greater" in chosen:
                if self.stats["Max Health"] < self.stats["Health"] + 25 * anti: 
                    self.stats["Health"] = self.stats["Max Health"]
                else:
                    self.stats["Health"] += round(25 * anti)
            elif "Max" in chosen: 
                if self.state == "Anti-Heal": 
                    if self.stats["Max Health"] < self.stats["Health"] + round(0.5 * self.stats["Max Health"]) : 
                        self.stats["Health"] = self.stats["Max Health"] 
                    else: 
                        self.stats["Health"] = self.stats["Health"] + round(0.5 * self.stats["Max Health"])
                else:
                    self.stats["Health"] = self.stats["Max Health"]

        if "Attack Potion" in chosen:
            if "Lesser" in chosen: 
                self.stats["Attack"] += 2 
            elif "Greater" in chosen:
                self.stats["Attack"] += 5
            elif "Max" in chosen:  
                self.stats["Attack"] += 8 

        if "Speed Potion" in chosen:
            if "Lesser" in chosen: 
                self.stats["Speed"] += 1
            elif "Greater" in chosen:
                self.stats["Speed"] += 2
            elif "Max" in chosen:  
                self.stats["Speed"] += 3 

        if "Experience Potion" in chosen: 
            if "Lesser" in chosen: 
                self.stats["Exp"] += 25
            elif "Greater" in chosen:
                self.stats["Exp"] += 75
            elif "Max" in chosen: 
                self.stats["Exp"] += 125  
            self.level_up()
        (self.items).pop(index) 

                
class dragon(entity):
    def __init__(self, phase, available = ["Infernal Drake", "Ocean Drake", "Cloud Drake", "Mountain Drake"]): 
        entity.__init__(self, phase)  
        if phase < 3:
            self.stats["Name"] = r.choice(available)
            if self.stats["Name"] == "Infernal Drake": 
                self.stats = makeStats(list=selectEnemy(phase=4)) 
            if self.stats["Name"] == "Ocean Drake": 
                self.stats = makeStats(list=selectEnemy(phase=5))  
            if self.stats["Name"] == "Cloud Drake": 
                self.stats = makeStats(list=selectEnemy(phase=6)) 
            if self.stats["Name"] == "Mountain Drake": 
                self.stats = makeStats(list=selectEnemy(phase=7))  
            for x in self.stats: 
                if x not in  ["Name", "Defense", "Crit"] :
                    self.stats[x] *= phase
        else: 
            self.stats["Name"] = "Elder Dragon" 
            self.stats = makeStats(list=selectEnemy(phase=8))  
        self.statCorrection(self.stats)
        print(intro[self.stats["Name"]]) 
                  
    def attack(self, obj, block):  
        if self.state == "Charging": 
            damage = 2 * self.stats["Attack"] * (1  - obj.stats["Defense"]) #base damage of the attack
            damage = round(damage) 
            if block: 
                damage *= 0.5 
                damage = round(damage) 
            obj.stats["Health"] -= damage       
            print(obj.stats["Name"], "was blasted by a charge attack for ", damage," damage.") 
            self.state = ""
        else:
            choice = r.randint(0, 9)  
            if choice <= 5: 
                entity.attack(self, obj, block)
            elif 6 <= choice <= 7:
                if self.state == "" :
                    print("The", self.stats["Name"], "is charging an attack.")
                    self.state = "Charging"
            else: 
                print("The", self.stats["Name"], "has inflicted a debuff upon you.")
                debuff = debuffs[self.stats["Name"]]
                obj.state == debuff
    
    
 

