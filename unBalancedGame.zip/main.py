import classes 
import random as r 
import matplotlib.pyplot as plt

def battle(enemy, block = False):
    if (enemy.state != "Slow") and (player.state != "Slow"): 
        if enemy.stats["Health"] > 0:
            if not block:
                if enemy.stats["Speed"] > player.stats["Speed"]:
                    enemy.attack(player, block)
                    if player.stats["Health"] <= 0:
                        player.death(enemy)
                    else:
                        player.attack(enemy)
                        if enemy.stats["Health"] <= 0:
                            print("You have defeated the " + enemy.stats["Name"] + ".")
                            if isinstance(enemy, classes.dragon): 
                                player.stats["Exp"] += 100 * (1.25 ** (player.stats["Level"])) 
                            else:
                                player.stats["Exp"] += enemy.exp_drop()
                            player.level_up()
                else:
                    player.attack(enemy)
                    if enemy.stats["Health"] <= 0:
                        print("You have defeated the " + enemy.stats["Name"] + ".")  
                        if isinstance(enemy, classes.dragon): 
                            player.stats["Exp"] += 100 * (1.25 ** (player.stats["Level"])) 
                        else:
                            player.stats["Exp"] += enemy.exp_drop()
                        player.level_up()
                    else:
                        enemy.attack(player, block)
                        if player.stats["Health"] <= 0:
                            player.death(enemy)
            else: 
                enemy.attack(player, True) 
                if player.stats["Health"] <= 0:
                    player.death(enemy)  

    if enemy.state == "Slow": 
        if enemy.stats["Health"] > 0:
            if not block:
                player.attack(enemy)
                if enemy.stats["Health"] <= 0:
                    print("You have defeated the " + enemy.stats["Name"] + ".")  
                    if isinstance(enemy, classes.dragon): 
                        player.stats["Exp"] += 100 * (1.25 ** (player.stats["Level"])) 
                    else:
                        player.stats["Exp"] += enemy.exp_drop()
                else:
                    enemy.attack(player, block)
                    if player.stats["Health"] <= 0:
                        player.death(enemy)
            else: 
                enemy.attack(player, True) 
                if player.stats["Health"] <= 0:
                    player.death(enemy)   

    if player.state == "Slow": 
        if enemy.stats["Health"] > 0:
            if not block:
                if enemy.stats["Speed"] > (player.stats["Speed"] - 2):
                    enemy.attack(player, block)
                    if player.stats["Health"] <= 0:
                        player.death(enemy)
                    else:
                        player.attack(enemy)
                        if enemy.stats["Health"] <= 0:
                            print("You have defeated the " + enemy.stats["Name"] + ".")
                            if isinstance(enemy, classes.dragon): 
                                player.stats["Exp"] += 100 * (1.25 ** (player.stats["Level"])) 
                            else:
                                player.stats["Exp"] += enemy.exp_drop()
                            player.level_up()
                else:
                    player.attack(enemy)
                    if enemy.stats["Health"] <= 0:
                        print("You have defeated the " + enemy.stats["Name"] + ".")  
                        if isinstance(enemy, classes.dragon): 
                            player.stats["Exp"] += 100 * (1.25 ** (player.stats["Level"])) 
                        else:
                            player.stats["Exp"] += enemy.exp_drop()
                    else:
                        enemy.attack(player, block)
                        if player.stats["Health"] <= 0:
                            player.death(enemy)
            else: 
                enemy.attack(player, True) 
                if player.stats["Health"] <= 0:
                    player.death(enemy)  


def take_inputs(enemy):
    print('\n') 
    if "Ocean" in player.buffs: 
        if player.stats["Health"] < player.stats["Max Health"]:
            print("The spirits of water have healed you.\n") 
            player.stats["Health"] += 1 

    print("Player HP:", player.stats["Health"] , '/' , player.stats["Max Health"]) 
    print(enemy.stats["Name"], "HP:", enemy.stats["Health"]) 

    a = input("What do you want to do? \n 1. Attack \n 2. Item \n 3. Block \n 4. Flee \n \n")
    a = a.strip()
    print('\n')

    if a == '!stats':
        b = input("Of who? \n" + "1. " + player.stats["Name"] + "\n 2. " + enemy.stats["Name"] + "\n")
        b = b.strip()
        if b == '1':
            player.printStats() 
        elif b == '2': 
            enemy.printStats()
        else:
            print("That is not a valid input." + '\n')
        take_inputs(enemy)

    elif a == "1": 
        battle(enemy) 
        if (enemy.stats["Health"] > 0) and (player.stats["Health"] > 0):
            take_inputs(enemy)  

    elif a == "2": 
        if len(player.items) == 0:
            print("You have no items.") 
            take_inputs(enemy) 
        else: 
            count = 1
            for x in player.items: 
                print(str(count) + '.', player.items[count - 1])
                count += 1 
            try: 
                b = int(input("What item will you use? \n")) 
                player.use(b - 1) 
                enemy.attack(player) 
                take_inputs(enemy)
            except: 
                print("That is not a valid input." + '\n')
                take_inputs(enemy) 

    elif a == "3":
        battle(enemy, True) 
        if (enemy.stats["Health"] > 0) and (player.stats["Health"] > 0):
            take_inputs(enemy) 

    elif a == "4": 
        print("You have fled.") 
        if len(player.items) > 3:
            chosen_i = r.choice(player.items) 
            print("You have dropped", chosen_i) 
            index = (player.items).index(chosen_i) 
            (player.items).pop(index)
            
    else:
        print("That is not a valid input." + '\n')
        take_inputs(enemy)

Stats = ['Level', 'Health', 'Defense', 'Attack', 'Speed', 'Crit', 'Exp', 'Max Health']
keepTrack = {'Level': [], 'Health': [], 'Defense': [], 'Attack': [], 'Speed': [] , 'Crit': [], 'Exp': [], 'Max Health': []}
def plot(stats_ot = keepTrack, stats = Stats): 
        print("\nWhich stat would you like to view?")  
        count = 1 
        for x in stats_ot: 
            if x != "Name":
                print(str(count) + '.', x) 
                count += 1  
        a = input("Enter the number of the stat you want to track. \n").strip() 
        try: 
            plt.plot(stats_ot[stats[int(a)-1]]) 
            plt.xlabel("Days")
            plt.show() 
        except: 
            print("That is not a valid input. \n") 

def gameOver(stats_ot):  
    print("Game Over." + "\n" + "Would you like to see your stat progression?" + "\n")
    a = input( "1. Yes \n2. No \n")  
    a = a.strip()
    if a == "1": 
        plot(stats_ot)
        gameOver(stats_ot)
    elif a == "2": 
        print("Game Over. Restart the application to play again.") 
        a = input()
        exit()
    else: 
        print("That is not a valid input. \n")  
        gameOver(stats_ot)

def challenge(phase, available_dragons):
        print("You find a dragon altar. Blood spills down the sides.")
        a = input("Challenge the dragon? \n 1. Yes \n 2. No \n").strip() 
        if a == "1": 
            dragon = classes.dragon(phase, available_dragons)
            take_inputs(dragon)  
            if dragon.stats["Health"] <= 0:
                if dragon.stats["Name"] != "Elder Dragon":
                    available_dragons.pop(available_dragons.index(dragon.stats["Name"]))
                    print(classes.beat[dragon.stats["Name"]])
                    (player.buffs).append( (dragon.stats["Name"].split())[0] )
                if phase == 1:
                    print("The enemies around you grow stronger as the seal of the dragon weakens.\n")
                elif phase == 2:
                    print("Enemies are now imbued with the power of the ancient spirits of light and dark. \nYou can feel terror running through your veins.\n")
                elif phase == 3: 
                    print("The terror within you has resided.")
                    print("The spirits have been freed. Congrats. You win!")
                    gameOver(keepTrack)
        elif a == "2":
            print("You ignore the dragon altar and move to the next room. \nOminous voices beg you to reconsider.\n")  
        else: 
            print("That is not a valid input.")
            challenge(phase)

def rooms(phase, roomnumber, available_dragons): 
    if (roomnumber % 25 == 0): 
        challenge(phase, available_dragons)
    else:
        choice = r.randint(1,10) 
        if choice <= 3: 
            ambient = (open('ambient.txt').read()).split('\n') 
            print(r.choice(ambient))   
        elif 4 <= choice <= 8: 
            enemy = classes.enemy(phase) 
            take_inputs(enemy)
        else: 
            print("A treasure chest lies in the middle of the room. You open it.")
            trapped = r.randint(1,10)
            if trapped == 1:
                print("The treasure chest was trapped! It smacks you in the face for 1 damage.")
                player.stats["Health"] -= 1
                print("Player HP:", player.stats["Health"] , '/' , player.stats["Max Health"]) 
                if player.stats["Health"] <= 0: 
                    print("Should have used that health potion.") 
                    print("Game Over") 
                    #dead = True
            else:
                choice = r.choice(["Health Potion", "Health Potion", "Health Potion", "Attack Potion", "Experience Potion"])
                if phase == 1: 
                    print("It contained a Lesser " + choice + ".")
                    player.items.append("Lesser " + choice)
                if phase == 2: 
                    print("It contained a Greater " + choice + ".")
                    player.items.append("Greater " + choice)
                if phase == 3: 
                    print("It contained a Max " + choice + ".")
                    player.items.append("Max " + choice)
    return roomnumber + 1

player = classes.player() 
print(player.type)
print("\n")  
print(player.stats)
print("\n")  
available_dragons = ["Infernal Drake", "Ocean Drake", "Cloud Drake", "Mountain Drake"]
roomnumber = 1
while player.stats["Health"] > 0: 
    phase = (4 - len(available_dragons)) + 1
    roomnumber = rooms(phase, roomnumber, available_dragons) 
    player.state = ""
    print("Days:", roomnumber)
    print("\n")
    if player.stats["Health"] > 0:
        a = input("Move to the next room? (Press Enter to continue, Press 1 to use an item, or type !stats to show your stat total) \n").strip() 
        print("")
        if a == "1":
            if len(player.items) == 0:
                print("You have no items.\n")  
            else: 
                count = 1
                for x in player.items: 
                    print(str(count) + '.', player.items[count - 1])
                    count += 1
                try: 
                    b = int(input("What item will you use? \n")) 
                    player.use(b - 1) 
                except: 
                    print("That is not a valid input." + '\n')  
        if a == "!stats" :
            player.printStats()
        print("\n")
        print(r.choice(["You have moved on to the next room. \n", "You continue on your journey. \n"]))
        if (player.stats["Health"] < player.stats["Max Health"]) and (roomnumber % 2 == 0): 
            print("You feel rejuvinated. You have healed for 1 health. \n")
            player.stats["Health"] += 1
        for x in player.stats:
            if x != "Name":
                keepTrack[x].append(player.stats[x]) 

gameOver(keepTrack)





